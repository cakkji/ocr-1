
# OCR Certificate System

## 🖥️ Frontend (Quasar)
```bash
cd frontend
quasar dev
```

## ⚙️ Backend (Express)
```bash
cd backend
npm install
node index.js
```

## 🔁 การทำงาน
1. อัปโหลดไฟล์ใบ Certificate
2. OCR อ่านข้อมูลด้วย Donut (mock)
3. แสดงผลลัพธ์บนหน้าเว็บ
4. กด "อนุมัติ" เพื่อเพิ่มชั่วโมงให้ผู้เรียน
